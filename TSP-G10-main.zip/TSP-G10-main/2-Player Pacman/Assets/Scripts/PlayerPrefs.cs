using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class PlayerPrefs : MonoBehaviour
{
    public static PlayerPrefs instance;

    public KeyCode up1 = KeyCode.W;
    public KeyCode down1 = KeyCode.S;
    public KeyCode left1 = KeyCode.A;
    public KeyCode right1 = KeyCode.D;

    public KeyCode up2 = KeyCode.I;
    public KeyCode down2 = KeyCode.K;
    public KeyCode left2 = KeyCode.J;
    public KeyCode right2 = KeyCode.L;
    public int characterIndex = 0;

    private static string SaveName = "2PPKeybind.txt";
    private string SavePath = $"{Directory.GetCurrentDirectory()}\\" + SaveName;

    
    void Awake() {
        
        if (instance == null) {
            instance = this;
            DontDestroyOnLoad(gameObject);
        } else {
            Destroy(gameObject);
        }
    }

    public void StartFromGame()
    {
        // Initialize from file
        if (!File.Exists(SavePath))
            return;

        string[] data = File.ReadAllLines(SavePath);
        string[] p1 = data[0].Split(',');
        string[] p2 = data[1].Split(',');

        KeyCode p1U = new KeyCode(); charToKeyCode.TryGetValue(p1[0][0], out p1U);
        KeyCode p1L = new KeyCode(); charToKeyCode.TryGetValue(p1[1][0], out p1L);
        KeyCode p1D = new KeyCode(); charToKeyCode.TryGetValue(p1[2][0], out p1D);
        KeyCode p1R = new KeyCode(); charToKeyCode.TryGetValue(p1[3][0], out p1R);
        KeyCode p2U = new KeyCode(); charToKeyCode.TryGetValue(p2[0][0], out p2U);
        KeyCode p2L = new KeyCode(); charToKeyCode.TryGetValue(p2[1][0], out p2L);
        KeyCode p2D = new KeyCode(); charToKeyCode.TryGetValue(p2[2][0], out p2D);
        KeyCode p2R = new KeyCode(); charToKeyCode.TryGetValue(p2[3][0], out p2R);

           up1 = p1U;
         left1 = p1L;
         down1 = p1D;
        right1 = p1R;

           up2 = p2U;
         left2 = p2L;
         down2 = p2D;
        right2 = p2R;
    }
    public void SetCharacter(int index)
    {
        characterIndex = index;
    }

    Dictionary<char, KeyCode> charToKeyCode = new Dictionary<char, KeyCode>()
    {
      //-------------------------LOGICAL mappings-------------------------
      
      //Lower Case Letters
      {'a', KeyCode.A},
      {'b', KeyCode.B},
      {'c', KeyCode.C},
      {'d', KeyCode.D},
      {'e', KeyCode.E},
      {'f', KeyCode.F},
      {'g', KeyCode.G},
      {'h', KeyCode.H},
      {'i', KeyCode.I},
      {'j', KeyCode.J},
      {'k', KeyCode.K},
      {'l', KeyCode.L},
      {'m', KeyCode.M},
      {'n', KeyCode.N},
      {'o', KeyCode.O},
      {'p', KeyCode.P},
      {'q', KeyCode.Q},
      {'r', KeyCode.R},
      {'s', KeyCode.S},
      {'t', KeyCode.T},
      {'u', KeyCode.U},
      {'v', KeyCode.V},
      {'w', KeyCode.W},
      {'x', KeyCode.X},
      {'y', KeyCode.Y},
      {'z', KeyCode.Z}
    };
}
