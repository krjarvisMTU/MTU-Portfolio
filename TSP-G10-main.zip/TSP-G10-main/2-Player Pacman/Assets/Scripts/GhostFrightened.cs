using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostFrightened : GhostBehavior
{
    public GameObject body;
    public GameObject eyes;
    public GameObject blue;
    public GameObject white;
    public bool eaten {get; private set;}

    public override void Enable(float duration) {
        base.Enable(duration);

        this.body.SetActive(false);
        this.eyes.SetActive(false);
        this.blue.SetActive(true);
        this.white.SetActive(false);

        Invoke(nameof(Flash), duration / 2.0f);
        
    }

    public override void Disable( ) {
        base.Disable();

        this.body.SetActive(true);
        this.eyes.SetActive(true);
        this.blue.SetActive(false);
        this.white.SetActive(false);
    }

    private void Flash( ) { 
        if (!this.eaten) {
            this.blue.SetActive(false);
            this.white.SetActive(true);
            this.white.GetComponent<AnimateSprites>().Reset();
        }
        
    }

    private void Eaten() {
        this.eaten = true;
        Vector3 position =  this.ghost.home.inside.position;
        position.z = this.ghost.transform.position.z;
        this.ghost.transform.position = position;

        this.ghost.home.Enable(this.duration);

        this.body.SetActive(false);
        this.eyes.SetActive(true);
        this.blue.SetActive(false);
        this.white.SetActive(false);
    }

    private void OnEnable( ) {
        blue.GetComponent<AnimateSprites>().Reset();
        this.ghost.movement.speedMultiplier = 0.5f;
        this.eaten = false;
    }

    private void OnDisable( ) {
        this.ghost.movement.speedMultiplier = 1.0f;
        this.eaten = false;
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            if (this.enabled) {
                Eaten();
            }

        }

    }

    private void OnTriggerEnter2D(Collider2D collider) {    
        Node node = collider.GetComponent<Node>();

        if (node != null && this.enabled) {
            Vector2 direction = Vector2.zero;
            float maxDistance = float.MinValue;
            
            foreach (Vector2 availableDirection in node.availableDirections) {
                Vector3 newPosition = this.transform.position + new Vector3(availableDirection.x, availableDirection.y, 0.0f);
                float distance = (this.ghost.target.position - newPosition).sqrMagnitude;

                if (distance > maxDistance) {
                    direction = availableDirection;
                    maxDistance = distance;
                }
            }

            this.ghost.movement.setDirection(direction);
            
        }

    }


}
