using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerPellet : Pellet
{
    public float duration = 8.0f;

    protected override void Eat( ) {
        FindObjectOfType<GameManager>().PowerPelletEaten(this);
        AudioManager audio = FindObjectsOfType<AudioManager>()[0];
        if (!audio.soundPlaying[3]) {
            audio.soundPlaying[3] = true;
            audio.playSound(audio.sounds[3]);
            Invoke(nameof(ResetEatSound), 0.20f);
        }
    }

    private void ResetEatSound( ) {
        AudioManager audio = FindObjectsOfType<AudioManager>()[0];
        audio.soundPlaying[3] = false;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            Eat();
            collider.GetComponent<PlayerController>().points += points;
        }
    }


}
