using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using System;

public class GameManager : MonoBehaviour
{
    public Transform pellets;
    public PlayerController[] pacmans;
    public List<PlayerController> pacmansDead {get; private set;}
    public Ghost[] ghosts;
    public GameObject[] AllPowerups;
    public Jail jail;
    public int ghostMultiplier { get; private set; } = 1;
    public int score = 0; // P1 Score
    public int score2 = 0; // P2 Score
    public TMP_Text scoreText;
    public int lives = 3; //{ get; private set; }
    public TMP_Text livesText;
    public int level = 0;
    public TMP_Text levelText;
    public bool itemActive = false;
    public int itemScore = 1000;
    public int itemDifference = 0;
    public int characterModel = 0;

    [SerializeField] private Text p1Score;
    [SerializeField] private Text p2Score;
    

    private void Start( ) {
        pacmans = GameObject.FindObjectsOfType<PlayerController>();
        pacmansDead = new List<PlayerController>();
        NewGame();
    }

    private void Update( ) {
        characterModel = FindObjectOfType<PlayerPrefs>().characterIndex;
        scoreText.text = "Total Score: " + score.ToString();
        if (pacmans.Length == 2)
        {
            p1Score.text = "P1 Score: " + pacmans[0].points.ToString();
            p2Score.text = "P2 Score: " + pacmans[1].points.ToString();
        }
        livesText.text = "Lives: " + lives.ToString();
        levelText.text = "Level: " + level.ToString();
        if (this.score - itemDifference > itemScore) {
            SpawnItem();
            itemScore *= 2;
        }
        
        foreach (PlayerController pacman in pacmans) {
            GameObject realPacman = pacman.gameObject;
            int iteration = 0;
            foreach (Transform child in realPacman.transform) {
                if (iteration == characterModel) {
                    child.gameObject.SetActive(true);
                } else {
                    child.gameObject.SetActive(false);
                }
                iteration++;
            }
        }
    
    }

    private void NewGame( ) {
        SetScore(0);
        SetLives(3);
        NewRound();
    }

    private void NewRound( ) {
        level++;
        foreach (Transform pellet in this.pellets) {
            pellet.gameObject.SetActive(true);
        }
        itemDifference = this.score;
        itemScore = 1000;
        ResetState();

    }

    private void ResetState( ) {
        for (int i = 0; i < ghosts.Length; i++) {
            this.ghosts[i].gameObject.SetActive(true);
            this.ghosts[i].resetState();
        }

         for (int i = 0; i < pacmans.Length; i++) {
            this.pacmans[i].gameObject.SetActive(true);
            this.pacmans[i].transform.GetChild(characterModel).gameObject.SetActive(true);
            this.pacmans[i].resetState();
        }   
        pacmansDead = new List<PlayerController>();
        jail.deadPacman = null;
        jail.gameObject.SetActive(false);
    }

    private void GameOver( ) {
        for (int i = 0; i < ghosts.Length; i++) {
            this.ghosts[i].gameObject.SetActive(false);
        }

        for (int i = 0; i < pacmans.Length; i++) {
            this.pacmans[i].gameObject.SetActive(false);
        }
        if (pacmans.Length == 1)
            TryNewHighScore1P();
        if (pacmans.Length == 2)
            TryNewHighScore2P();
        SceneManager.LoadScene("Main Menu");
    }

    private void TryNewHighScore1P()
    {
        int localScore = pacmans[0].points;

        // Single Player
        string filepath = System.IO.Directory.GetCurrentDirectory() + "\\2PPSave.txt";
        string[] data = System.IO.File.ReadAllLines(filepath);
        for (int i = data.Length - 1; i > 0; i--)
        {
            if (score > int.Parse(data[0].Split(",")[i].Split(':')[1]))
            {
                data[1] = $"newscore={score}";
                break;
            }
        }
        System.IO.File.WriteAllLines(filepath, data);
        SceneManager.LoadScene("Leaderboard");
    }
    private void TryNewHighScore2P()
    {
        // Two Player
        string filepath = System.IO.Directory.GetCurrentDirectory() + "\\2PPSave.txt";
        string[] data = System.IO.File.ReadAllLines(filepath);
        for (int i = data.Length - 1; i > 0; i--)
        {
            if (score > Math.Max(int.Parse(data[2].Split(",")[i].Split(':')[1]), int.Parse(data[3].Split(",")[i].Split(':')[1])))
            {
                data[4] = $"newscores={pacmans[0].points},{pacmans[1].points}";
                break;
            }
        }
        System.IO.File.WriteAllLines(filepath, data);
        SceneManager.LoadScene("Leaderboard");
    }

    private void SetScore(int score) {
        this.score = score;

    }

    private void SetLives(int lives) {
        this.lives = lives;
    }

    public void GhostEaten(Ghost ghost, PlayerController pacman, int points) {
        pacman.points += (points * ghostMultiplier);
        SetScore(this.score + (ghost.points * this.ghostMultiplier));
        ghostMultiplier++;
        AudioManager audio = FindObjectOfType<AudioManager>();
        audio.playSound(audio.sounds[2]);
    }

    public void PacmanEaten(PlayerController player) {
        player.gameObject.SetActive(false);
        player.gameObject.transform.position = new Vector3(1000f, 1000f, 1f);
        player.direction = Vector2.zero;
        player.nextDirection = Vector2.zero;
        SpriteRenderer sprite = player.transform.GetChild(FindObjectOfType<GameManager>().characterModel).gameObject.GetComponent<SpriteRenderer>();
        sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, 1.0f);
        player.speedMultiplier = 1.0f;
        pacmansDead.Add(player);
        
        if (pacmansDead.Count >= pacmans.Length) {
            for (int i = 0; i < pacmans.Length; i++) {
                this.pacmans[i].gameObject.SetActive(false);
            } 
            SetLives(this.lives - 1);

            if (this.lives > 0) {
                Invoke(nameof(ResetState), 3.0f);
            } else {
                GameOver();
            }
            return;
        }

        jail.gameObject.SetActive(true);
        jail.deadPacman = player;
        jail.gameObject.transform.GetChild(characterModel).gameObject.SetActive(true);
        jail.gameObject.transform.position = jail.possiblePositions[UnityEngine.Random.Range(0, jail.possiblePositions.Length)];

    }

    public void PacmanRevived(PlayerController player, Vector3 location) {
        for (int i = 0; i < pacmansDead.Count; i++) {
            if (pacmansDead[i] == player) {
                pacmansDead.RemoveAt(i);
            }
        }
        player.gameObject.SetActive(true);
        player.gameObject.transform.position = new Vector3(location.x, location.y - 0.5f, location.z);
    }

    public void PelletEaten(Pellet pellet) {
        pellet.gameObject.SetActive(false);
        SetScore(this.score + pellet.points);

        if (!PelletsRemaining()) {
            for (int i = 0; i < pacmans.Length; i++) {
                this.pacmans[i].gameObject.SetActive(false);
            } 
            Invoke(nameof(NewRound), 3.0f);
        }
    }

    public void PowerPelletEaten(PowerPellet pellet) {
        for (int i = 0; i < this.ghosts.Length; i++) {
            this.ghosts[i].frightened.Enable(pellet.duration);
        }

        PelletEaten(pellet);
        //CancelInvoke();
        Invoke(nameof(ResetGhostMultiplier), pellet.duration);
    }

    public void SpeedBoostEaten(SpeedBoost powerup) {
        powerup.gameObject.SetActive(false);
        itemActive = false;
        SetScore(this.score + powerup.points);
    }

    public void InvisibilityEaten(Invisible powerup) {
        powerup.gameObject.SetActive(false);
        itemActive = false;
        SetScore(this.score + powerup.points);
    }

    public void FreezeEaten(Freeze powerup) {
        powerup.gameObject.SetActive(false);
        itemActive = false;
        SetScore(this.score + powerup.points);
    }

    public void ChaosEaten(Chaos powerup) {
        powerup.gameObject.SetActive(false);
        itemActive = false;
        SetScore(this.score + powerup.points);
    }

    public void SpawnItem( ) {
        if (itemActive) {
            return;
        }

        itemActive = true;
        GameObject spawnedItem = AllPowerups[UnityEngine.Random.Range(0, AllPowerups.Length)];
        spawnedItem.gameObject.SetActive(true);

    }

    private bool PelletsRemaining( ) {
        foreach (Transform pellet in this.pellets) {
            if (pellet.gameObject.activeSelf) {
                return true;
            }
        }
        return false;
    }

    private void ResetGhostMultiplier( ) {
        this.ghostMultiplier = 1;
    }

}
