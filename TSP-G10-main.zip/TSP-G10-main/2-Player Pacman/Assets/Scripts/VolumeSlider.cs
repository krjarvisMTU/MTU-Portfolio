using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VolumeSlider : MonoBehaviour
{
   public Slider slider;
   public AudioManager audioManager;

   void Start( ) {
        audioManager = GameObject.FindObjectsOfType<AudioManager>()[0];

        slider.value = audioManager.volume;
        slider.onValueChanged.AddListener(val => audioManager.changeVolume(val));
   }

   void Update( ) {
       slider.value = audioManager.volume;
   }
}
