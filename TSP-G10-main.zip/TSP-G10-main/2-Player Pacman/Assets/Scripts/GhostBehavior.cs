using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Ghost))]
public abstract class GhostBehavior : MonoBehaviour {

    public Ghost ghost { get; private set; }
    public float duration;
    public AudioManager audio {get; private set;}
    

    private void Awake( ) {
        this.ghost = GetComponent<Ghost>();
        this.audio = FindObjectOfType<AudioManager>();
        //this.enabled = false;
    }

    public void Enable( ) {
        Enable(this.duration);
    }

    public virtual void Enable(float duration) {
        this.enabled = true;
        CancelInvoke();
        Invoke(nameof(Disable), duration);
    }

    

    public virtual void Disable( ) {
        this.enabled = false;
        CancelInvoke();


    }


}
