using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimateSprites : MonoBehaviour
{

    public SpriteRenderer spriteRenderer { get; private set; }
    public Sprite[] sprites;
    public float animationTime = 0.25f;
    public int frame { get; private set; }
    public bool loop = true;


    private void OnEnable()
    {
        spriteRenderer.enabled = true;
    }

    private void OnDisable()
    {
        spriteRenderer.enabled = false;
    }


    private void Awake( ) {
        this.spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start( ) {
        InvokeRepeating(nameof(Advance), this.animationTime, this.animationTime);
    }

    private void Advance( ) {

        if (spriteRenderer == null) {
            return;
        }
        
        this.frame++;
        if (this.frame >= this.sprites.Length && this.loop) {
            frame = 0;
        }

        if (this.frame >= 0 && this.frame < this.sprites.Length) {
            this.spriteRenderer.sprite = this.sprites[this.frame];
        }

    }

    public void Reset( ) {
        this.frame = -1;
        Advance();
    }
   
}
