using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using TMPro;

public class Keybinds : MonoBehaviour
{
    [SerializeField] private InputField[] bindButtons;

    private char[] binds = new char[8]; // index 0 - 3: player 1 ULDR, index 4 - 7: player 2 ULDR
    private static string SaveName = "2PPKeybind.txt";
    private string SavePath = $"{Directory.GetCurrentDirectory()}\\" + SaveName;

    void Start()
    {
        // Initialize from file
        if (!File.Exists(SavePath))
        {
            string p1 = "w,a,s,d";
            string p2 = "i,j,k,l";
            File.WriteAllText(SavePath, $"{p1}\n{p2}");
        }
        // Initialize Array
        string[] data = File.ReadAllLines(SavePath);
        string[] p1File = data[0].Split(',');
        string[] p2File = data[1].Split(',');
        for (int i = 0; i < 4; i++)
            binds[i] = p1File[i].ToCharArray()[0];
        for (int i = 0; i < 4; i++)
            binds[i + 4] = p2File[i].ToCharArray()[0];

        for (int i = 0; i < bindButtons.Length; i++)
            bindButtons[i].GetComponent<InputField>().text = binds[i].ToString();
    }
    void Update()
    {
        //

    }

    public void SetKeyBind(int whichOne)
    {
        print($"Which one: {whichOne}");
        char newBind = bindButtons[whichOne].text[0];
        binds[whichOne] = newBind;

        string p1 = "";
        for (int i = 0; i < 4; i++)
            p1 += $"{binds[i]}{(i < binds.Length - 5 ? "," : "")}";
        string p2 = "";
        for (int i = 4; i < binds.Length; i++)
            p2 += $"{binds[i]}{(i < binds.Length - 1 ? "," : "")}";
        File.Create(SavePath).Close();
        File.WriteAllText(SavePath, $"{p1}\n{p2}");
    }
}

