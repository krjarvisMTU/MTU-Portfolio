using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Invisible : MonoBehaviour
{
    public PlayerController Pacman;
    public Ghost[] Ghosts;
    public int points = 500;

    public void Awake( ) {
        Ghosts = FindObjectOfType<GameManager>().ghosts;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            FindObjectOfType<GameManager>().InvisibilityEaten(this);       
            Pacman = collider.gameObject.GetComponent<PlayerController>();
            SpriteRenderer sprite = Pacman.transform.GetChild(FindObjectOfType<GameManager>().characterModel).gameObject.GetComponent<SpriteRenderer>();
            sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, 0.25f);
            foreach (Ghost ghost in Ghosts) {
                ghost.scatter.Enable(8.0f);
            }
            CancelInvoke();
            Invoke(nameof(ResetInvisible), 8.0f);
            collider.GetComponent<PlayerController>().points += points;
        }
    }

    public void ResetInvisible( ) {
        SpriteRenderer sprite = Pacman.transform.GetChild(FindObjectOfType<GameManager>().characterModel).gameObject.GetComponent<SpriteRenderer>();
        sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, 1.0f);
        this.Pacman = null;
    }

}
