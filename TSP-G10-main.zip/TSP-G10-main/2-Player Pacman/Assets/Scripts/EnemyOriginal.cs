using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyOriginal : MonoBehaviour
{
    public int points = 200;
    public float speed = 5.0f;
    public float speedMultiplier = 1.0f;
    public Rigidbody2D rb;
    public Vector2 initialDirection;
    public Vector2 direction { get; private set; }
    public Vector2 nextDirection { get; private set; }
    public Vector3 startingPosition { get; private set; }

    public PlayerController player;
    private float distance;
    public float radiusActivated;

    

    void Awake() {
        this.rb = GetComponent<Rigidbody2D>();
        this.startingPosition = this.transform.position;
    }

    void Start() {
        resetState();
    }

    void FixedUpdate() {
        Vector2 position = this.rb.position;
        Vector2 translation = this.direction * this.speed * this.speedMultiplier * Time.fixedDeltaTime;
        this.rb.MovePosition(position + translation);
    }

    void Update() {
        chaseMovement();
    }

    public void resetState() {
        this.speedMultiplier = 1.0f;
        this.direction = this.initialDirection;
        this.nextDirection = Vector2.zero;
        this.transform.position = this.startingPosition;
    }

    public void chaseMovement( ) {
        distance = Vector2.Distance(this.transform.position, player.transform.position);
        Vector2 direction = player.transform.position - this.transform.position;
        direction.Normalize();

        if (player.poweredUp) {
            speedMultiplier = 0.5f;
            if (distance < radiusActivated) {
                this.direction = -direction;
            } else {
                this.direction = Vector2.zero;
            }
        } else {
            speedMultiplier = 1f;
             if (distance < radiusActivated) {
                this.direction = direction;
            } else {
                this.direction = Vector2.zero;
            }
        }

    }

}
