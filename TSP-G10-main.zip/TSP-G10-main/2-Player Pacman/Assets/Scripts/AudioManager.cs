using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public AudioClip[] sounds;
    public static AudioManager instance;
    public bool[] soundPlaying;
    public float volume = 1; 
    [SerializeField] private AudioSource musicSource, effectsSource;

    void Awake( ) {
        soundPlaying[3] = false;
        if (instance == null) {
            instance = this;
            DontDestroyOnLoad(gameObject);
        } else {
            Destroy(gameObject);
        }

    }

    public void playSound(AudioClip clip) {
        effectsSource.PlayOneShot(clip);
    }

    public void changeVolume(float value) {
        AudioListener.volume = value;
        volume = value;
    }

}
