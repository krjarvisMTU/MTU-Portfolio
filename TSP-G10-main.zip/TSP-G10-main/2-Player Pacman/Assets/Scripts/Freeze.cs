using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Freeze : MonoBehaviour
{
    public PlayerController Pacman;
    public Ghost[] Ghosts;
    public int points = 500;

    public void Awake( ) {
        Ghosts = FindObjectOfType<GameManager>().ghosts;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            FindObjectOfType<GameManager>().FreezeEaten(this);       
            Pacman = collider.gameObject.GetComponent<PlayerController>();
            foreach (Ghost ghost in Ghosts) {
                ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 0.0f;
            }
            CancelInvoke();
            Invoke(nameof(ResetIce), 8.0f);
            Invoke(nameof(ResetFreeze), 12.0f);
            collider.GetComponent<PlayerController>().points += points;
        }
    }

    public void ResetIce( ) {
        foreach (Ghost ghost in Ghosts) {
            ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 0.5f;
        }
    }

    public void ResetFreeze( ) {
        foreach (Ghost ghost in Ghosts) {
            ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 1.0f;
        }
        this.Pacman = null;
    }

}
