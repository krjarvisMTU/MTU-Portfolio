using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeColor : MonoBehaviour
{
    public Button button1;
    public Button button2;
    public Button button3;
    public int index;

    
    public void Update( ) {
        int modelIndex = FindObjectOfType<PlayerPrefs>().characterIndex;
        if (modelIndex == 0) {
            button1.image.color = Color.green;
            button2.image.color = Color.red;
            button3.image.color = Color.red;
        } else if (modelIndex == 1) {
            button1.image.color = Color.red;
            button2.image.color = Color.green;
            button3.image.color = Color.red;
        } else if (modelIndex == 2) {
            button1.image.color = Color.red;
            button2.image.color = Color.red;
            button3.image.color = Color.green;
        }
    } 

    public void ToggleColor(Button clickedButton) {
        button1.image.color = Color.red;
        button2.image.color = Color.red;
        button3.image.color = Color.red;
        clickedButton.image.color = Color.green;
        FindObjectOfType<PlayerPrefs>().characterIndex = index;
    }

}
