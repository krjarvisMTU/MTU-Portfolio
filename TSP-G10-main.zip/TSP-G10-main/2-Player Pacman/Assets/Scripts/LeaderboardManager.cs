using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using TMPro;
using System;

public class Leaderboard : MonoBehaviour
{
    [SerializeField] private GameObject SelectorBar;
    [SerializeField] private GameObject[] selectors = new GameObject[10];
    [SerializeField] private GameObject[] placeText = new GameObject[10];
    [SerializeField] private GameObject p1Username;
    [SerializeField] private GameObject p2Username;
    [SerializeField] private GameObject p2Header;
    [SerializeField] private GameObject TwoPSpec;
    [SerializeField] private GameObject HighScoreBox;
    [SerializeField] private GameObject NameInputField;
    [SerializeField] private GameObject ModeDropdown;

    private const float alphaMin = 0.15f;
    private const float alphaMax = 0.60f;
    private const float alphaChange = 0.08f;
    private const float wait = 0.05f;
    private float alpha = 1.0f;
    private float timer = 0;
    private bool inc = false;

    private const string SaveName = "2PPsave.txt";
    private string SavePath = Directory.GetCurrentDirectory() + "\\" + SaveName;

    // Single
    private int newHighScoreSP = -1;
    private string[] top10namesSP = new string[10];
    private int[] top10scoresSP = new int[10];
    // Two Player
    private int newHighScoreTP1 = -1;
    private int newHighScoreTP2 = -1;
    private string[] top10namesTP1 = new string[10];
    private int[] top10scoresTP1 = new int[10];
    private string[] top10namesTP2 = new string[10];
    private int[] top10scoresTP2 = new int[10];

    private int mode = 0; // 0 = Single Player, 1 = Two Player
    private string p1nameInput = "";

    [SerializeField] private RawImage bkg;
    [SerializeField] private float x, y;

    void Start()
    {
        // Load Save File
        if (!File.Exists(SavePath))
        {
            var stream = File.Create(SavePath);
            stream.Close();
            string[] DefaultData = {"---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1", // 0: 1 Player Records
                                    "newscore=-1",                                                           // 1: 1 Player Newscore Entry
                                    "---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1", // 2: 2 Player - Player 1 Records
                                    "---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1,---:-1", // 3: 2 Player - Player 2 Records
                                    "newscores=-1,-1"};                                                      // 4: 2 Player Newscore Entry
            File.WriteAllLines(SavePath, DefaultData);
            print($"Created new save file '{SavePath}'");
        }
        
        // CheckFileIntegrity

        string[] data = File.ReadAllLines(SavePath);
        string[] placementS = data[0].Split(',');
        string[] placementT1 = data[2].Split(',');
        string[] placementT2 = data[3].Split(',');
        for (int i = 0; i < placementS.Length; i++) // Load Single Player
        {
            top10namesSP[i] = placementS[i].Split(':')[0];
            top10scoresSP[i] = int.Parse(placementS[i].Split(':')[1]);
        }
        for (int i = 0; i < placementT1.Length; i++) // Load Two Player
        {
            top10namesTP1[i] = placementT1[i].Split(':')[0];
            top10namesTP2[i] = placementT2[i].Split(':')[0];
            top10scoresTP1[i] = int.Parse(placementT1[i].Split(':')[1]);
            top10scoresTP2[i] = int.Parse(placementT2[i].Split(':')[1]);
        }
        newHighScoreSP = int.Parse(data[1].Split('=')[1]);
        newHighScoreTP1 = int.Parse(data[4].Split('=')[1].Split(',')[0]);
        newHighScoreTP2 = int.Parse(data[4].Split('=')[1].Split(',')[1]);

        print($"new high score: '{newHighScoreSP}'");
        p2Username.SetActive(false);
        p2Header.SetActive(false);
        if (newHighScoreSP != -1)
        {
            mode = 0;
            ModeDropdown.GetComponent<TMP_Dropdown>().value = mode = 0;
            HighScoreBox.SetActive(true);
            TwoPSpec.SetActive(false);
        }
        else if (newHighScoreTP1 != -1)
        {
            mode = 1;
            ModeDropdown.GetComponent<TMP_Dropdown>().value = mode = 1;
            p2Username.SetActive(true);
            p2Header.SetActive(true);
            HighScoreBox.SetActive(true);
            TwoPSpec.GetComponent<Text>().text = "Please enter name for Player One";
        }

        // Initialize Top 10
        InitializeTopTen(mode);
    }
    void Update()
    {
        // Selector Fade Effect
        timer += Time.deltaTime;
        if (timer >= wait)
        {
            timer = 0;
            if (inc)
                alpha = (alpha + alphaChange) >= 1 ? 1 : (alpha + alphaChange);
            else
                alpha -= alphaChange;
            if (alpha <= alphaMin)
                inc = true;
            if (alpha >= alphaMax)
                inc = false;
            SelectorBar.GetComponent<CanvasRenderer>().SetAlpha(alpha);
        }

        // Bkg Scrolling Effect
        bkg.uvRect = new Rect(bkg.uvRect.position + new Vector2(x, y) * Time.deltaTime, bkg.uvRect.size);
    }

    public void MoveSelector(int n)
    {
        if (HighScoreBox.active)
            return;
        SelectorBar.transform.position = selectors[n].transform.position;
        
        if (mode == 0)
        {
            string exp = "";
            if (top10namesSP[n].Equals("---"))
                exp = "---";
            else
            {
                for (int i = 0; i < 14 - top10namesSP[n].Length; i++)
                    exp += "  ";
                exp += top10namesSP[n] + " - " + top10scoresSP[n];
            }
            p1Username.GetComponent<Text>().text = exp;
        }
        else if (mode == 1)
        {
            string exp1 = "";
            string exp2 = "";
            if (top10namesTP1[n].Equals("---"))
                exp1 = "---";
            if (top10namesTP1[n].Equals("---"))
                exp2 = "---";
            else
            {
                for (int i = 0; i < 14 - top10namesTP1[n].Length; i++)
                    exp1 += "  ";
                exp1 += top10namesTP1[n] + " - " + top10scoresTP1[n];
                for (int i = 0; i < 14 - top10namesTP2[n].Length; i++)
                    exp2 += "  ";
                exp2 += top10namesTP2[n] + " - " + top10scoresTP2[n];
            }
            p1Username.GetComponent<Text>().text = exp1;
            p2Username.GetComponent<Text>().text = exp2;
        }
    }
    public void NewHighScore()
    {
        if (NameInputField.GetComponent<InputField>().text.Equals("---"))
            return;

        if (p1nameInput.Equals(""))
        {
            p1nameInput = NameInputField.GetComponent<InputField>().text;
            TwoPSpec.GetComponent<Text>().text = "Please enter name for Player Two";
            return;
        }

        if (mode == 0)
        {
            int newScore = int.Parse(File.ReadAllLines(SavePath)[1].Split('=')[1]);

            int intPrev = newScore;
            int intTemp = 0;
            string strPrev = NameInputField.GetComponent<InputField>().text;
            string strTemp = "";
            bool last = true;
            for (int i = 0; i < top10scoresSP.Length; i++)
            {
                if (i == top10scoresSP.Length - 1 && newScore > top10scoresSP[i] && last)
                {
                    top10scoresSP[i] = newScore;
                    top10namesSP[i] = strPrev;
                }
                else if (intPrev >= top10scoresSP[i])
                {
                    last = false;

                    intTemp = top10scoresSP[i];
                    top10scoresSP[i] = intPrev;
                    intPrev = intTemp;

                    strTemp = top10namesSP[i];
                    top10namesSP[i] = strPrev;
                    strPrev = strTemp;
                }
            }
        }
        else if (mode == 1)
        {
            int newScore1 = int.Parse(File.ReadAllLines(SavePath)[4].Split('=')[1].Split(',')[0]);
            int newScore2 = int.Parse(File.ReadAllLines(SavePath)[4].Split('=')[1].Split(',')[1]);
            int newScore = Math.Max(newScore1, newScore2);

            int intPrev = -1;
            string useName = "";

            if (newScore1 >= newScore2)
                useName = p1nameInput;
            else if (newScore1 < newScore2)
                useName = NameInputField.GetComponent<InputField>().text;
            
            intPrev = newScore;
            int intPrev2 = newScore2;
            int intTemp = 0;
            int intTemp2 = 0;
            string strPrev = useName;
            string strPrev2 = NameInputField.GetComponent<InputField>().text;
            string strTemp = "";
            string strTemp2 = "";
            bool last = true;
            for (int i = 0; i < top10scoresTP1.Length; i++)
            {
                if (i == top10scoresTP1.Length - 1 && (newScore > Math.Max(top10scoresTP1[i], top10scoresTP2[i])) && last)
                {
                    top10scoresTP1[i] = newScore;
                    top10namesTP1[i] = strPrev;
                    top10scoresTP2[i] = newScore2;
                    top10namesTP2[i] = NameInputField.GetComponent<InputField>().text;
                }
                else if (intPrev >= Math.Max(top10scoresTP1[i], top10scoresTP2[i]))
                {
                    last = false;

                    intTemp = top10scoresTP1[i];
                    intTemp2 = top10scoresTP2[i];
                    top10scoresTP1[i] = intPrev;
                    top10scoresTP2[i] = intPrev2;
                    intPrev = intTemp;
                    intPrev2 = intTemp2;

                    strTemp = top10namesTP1[i];
                    strTemp2 = top10namesTP2[i];
                    top10namesTP1[i] = strPrev;
                    top10namesTP2[i] = strPrev2;
                    strPrev = strTemp;
                    strPrev2 = strTemp2;
                }
            }
        }
        
        InitializeTopTen(mode);
        SaveToFile();
        HighScoreBox.SetActive(false);
    }
    private void InitializeTopTen(int mode)
    {
        if (mode == 0)
            for (int i = 0; i < placeText.Length; i++)
                placeText[i].GetComponent<Text>().text = top10namesSP[i];
        else if (mode == 1)
        {
            for (int i = 0; i < placeText.Length; i++)
            {
                if (top10scoresTP1[i] >= top10scoresTP2[i])
                    placeText[i].GetComponent<Text>().text = top10namesTP1[i];
                else if (top10scoresTP1[i] < top10scoresTP2[i])
                    placeText[i].GetComponent<Text>().text = top10namesTP2[i];
            }
        }
    }
    public void SaveToFile()
    {
        string exp0 = "";
        string exp1 = "newscore=-1";
        string exp2 = "";
        string exp3 = "";
        string exp4 = "newscores=-1,-1";

        for (int i = 0; i < top10scoresSP.Length; i++) // SP
            exp0 += $"{top10namesSP[i]}:{top10scoresSP[i]}{(i == top10scoresSP.Length - 1 ? "" : ",")}";
        for (int i = 0; i < top10scoresTP1.Length; i++) // TP p1
            exp2 += $"{top10namesTP1[i]}:{top10scoresTP1[i]}{(i == top10scoresTP1.Length - 1 ? "" : ",")}";
        for (int i = 0; i < top10scoresTP2.Length; i++) // TP p2
            exp3 += $"{top10namesTP2[i]}:{top10scoresTP2[i]}{(i == top10scoresTP2.Length - 1 ? "" : ",")}";
        string exp = $"{exp0}\n{exp1}\n{exp2}\n{exp3}\n{exp4}\n";
        File.WriteAllText(SavePath, exp);
    }
    public void ChangeMode()
    {
        mode = ModeDropdown.GetComponent<TMP_Dropdown>().value;
        if (mode == 0)
        {
            p2Username.SetActive(false);
            p2Header.SetActive(false);
        }
        else if (mode == 1)
        {
            p2Username.SetActive(true);
            p2Header.SetActive(true);
        }
        InitializeTopTen(mode);
    }
}
