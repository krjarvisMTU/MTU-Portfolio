using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedBoost : MonoBehaviour
{
    public PlayerController Pacman;
    public int points = 500;

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            FindObjectOfType<GameManager>().SpeedBoostEaten(this);       
            Pacman = collider.gameObject.GetComponent<PlayerController>();
            Pacman.speedMultiplier = 1.5f;
            CancelInvoke();
            Invoke(nameof(ResetSpeed), 8.0f);
            collider.gameObject.GetComponent<PlayerController>().points += points;
        }
    }

    public void ResetSpeed( ) {
        Pacman.speedMultiplier = 1.0f;
        this.Pacman = null;
    }
}
