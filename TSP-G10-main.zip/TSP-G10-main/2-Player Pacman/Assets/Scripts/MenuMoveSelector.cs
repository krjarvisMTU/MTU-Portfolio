using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuMoveSelector : MonoBehaviour
{
    [SerializeField] private int x1p = -212;
    [SerializeField] private int y1p = -110;

    [SerializeField] private int x2p = 45;
    [SerializeField] private int y2p = -110;
                                     
    [SerializeField] private int xlb = -212;
    [SerializeField] private int ylb = -199;
                                     
    [SerializeField] private int xcc = 45;
    [SerializeField] private int ycc = -199;

    [SerializeField] private Image sel;

    private float interval = 0.5f;
    private float prevTime = 0f;
    bool tsp = false;
    Color tspColor = Color.black;
    Color whiteColor = Color.white;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (prevTime < interval)
            prevTime += Time.deltaTime;
        else
        {
            prevTime = 0;
            if (tsp)
                sel.color = tspColor;
            else
                sel.color = whiteColor;
            tsp = !tsp;
        }
    }

    public void MoveSelector(int where)
    {
        switch (where)
        {
            case 0:
                sel.GetComponent<RectTransform>().localPosition = new Vector3(x1p, y1p, 0);
                break;
            case 1:
                sel.GetComponent<RectTransform>().localPosition = new Vector3(x2p, y2p, 0);
                break;
            case 2:
                sel.GetComponent <RectTransform>().localPosition = new Vector3(xlb, ylb, 0);
                break;
            case 3:
                sel.GetComponent<RectTransform>().localPosition = new Vector3(xcc, ycc, 0);
                break;
        }
    }
}
