using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class EnemyController : MonoBehaviour {
    public LayerMask obstacleLayer;
    public float speed = 7.0f;
    public float speedMultiplier = 1.0f;
    public float frozenMultiplier = 1.0f;
    public Vector2 initialDirection;
    public Rigidbody2D rb {get; private set;}
    public Vector2 direction { get; private set; }
    public Vector2 nextDirection { get; private set; }
    public Vector3 startingPosition { get; private set; }
    public Ghost ghost { get; private set; }
    public PlayerController[] players {get; private set;}
    

    void Awake() {
        this.rb = GetComponent<Rigidbody2D>();
        this.startingPosition = this.transform.position;
        this.ghost = GetComponent<Ghost>();
        this.players = FindObjectOfType<GameManager>().pacmans;
    }
    
    void Start() {
        resetState();
    }

    void FixedUpdate() {
        Vector2 position = this.rb.position;
        Vector2 translation = this.direction * this.speed * this.speedMultiplier * frozenMultiplier * Time.fixedDeltaTime;
        this.rb.MovePosition(position + translation);
    }

    void Update() {
        if (this.nextDirection != Vector2.zero) {
            setDirection(this.nextDirection);
        }

        if (players.Length > 1) {
            float minDistance = float.MaxValue;
            foreach (PlayerController target in players) {
                float distance = Vector2.Distance(this.transform.position, target.transform.position);
                if (distance < minDistance) {
                    minDistance = distance;
                    ghost.target = target.transform;
                }
            }
        }

    }

    public void resetState() {
        this.speed = 7.0f;
        this.speedMultiplier = 1.0f;
        this.frozenMultiplier = 1.0f;
        this.direction = this.initialDirection;
        this.nextDirection = Vector2.zero;
        this.transform.position = this.startingPosition;
        this.rb.isKinematic = false;
        this.enabled = true;
    }

    public void setDirection(Vector2 direction, bool forced = false) {
        if (!Occupied(direction) || forced) {
            this.direction = direction;
            this.nextDirection = Vector2.zero;
        } else {
            this.nextDirection = direction;
        }

    }

    public bool Occupied(Vector2 direction) {
        RaycastHit2D hit = Physics2D.BoxCast(this.transform.position, Vector2.one * 0.75f, 0.0f, direction, 1.5f, this.obstacleLayer);
        return hit.collider != null;
    }   

}
