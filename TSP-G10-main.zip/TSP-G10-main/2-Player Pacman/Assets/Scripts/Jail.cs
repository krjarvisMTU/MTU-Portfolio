using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jail : MonoBehaviour
{
    public PlayerController deadPacman;
    public Vector3[] possiblePositions;


    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            FindObjectOfType<GameManager>().PacmanRevived(deadPacman, this.gameObject.transform.position);
            this.gameObject.SetActive(false);
        }
    }


}
