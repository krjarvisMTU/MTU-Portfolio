using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Pellet : MonoBehaviour
{
    public int points = 10;

    protected virtual void Eat( ) {
        FindObjectOfType<GameManager>().PelletEaten(this);
        AudioManager audio = FindObjectsOfType<AudioManager>()[0];
        if (!audio.soundPlaying[3]) {
            audio.soundPlaying[3] = true;
            audio.playSound(audio.sounds[3]);
            Invoke(nameof(ResetEatSound), 0.20f);
        }
    }

    private void ResetEatSound( ) {
        AudioManager audio = FindObjectsOfType<AudioManager>()[0];
        audio.soundPlaying[3] = false;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            Eat();
            collider.GetComponent<PlayerController>().points += points;
        }
    }

}
