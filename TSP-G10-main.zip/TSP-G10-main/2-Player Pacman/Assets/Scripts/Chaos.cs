using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chaos : MonoBehaviour
{
    public PlayerController Pacman;
    public Ghost[] Ghosts;
    public int points = 500;

    public void Awake( ) {
        Ghosts = FindObjectOfType<GameManager>().ghosts;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.gameObject.layer == LayerMask.NameToLayer("Pacman")) {
            FindObjectOfType<GameManager>().ChaosEaten(this);       
            Pacman = collider.gameObject.GetComponent<PlayerController>();
            Pacman.speedMultiplier = 1.5f;
            SpriteRenderer sprite = Pacman.transform.GetChild(FindObjectOfType<GameManager>().characterModel).gameObject.GetComponent<SpriteRenderer>();
            sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, 0.25f);
            foreach (Ghost ghost in Ghosts) {
                ghost.scatter.Enable(12.0f);
                ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 0.0f;
            }
            CancelInvoke();
            Invoke(nameof(ResetIce), 6.0f);
            Invoke(nameof(Reset), 12.0f);
            collider.gameObject.GetComponent<PlayerController>().points += points;
        }
    }

    public void ResetIce( ) {
        foreach (Ghost ghost in Ghosts) {
            ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 0.5f;
        }
    }

    public void Reset( ) {
        Pacman.speedMultiplier = 1.0f;

        SpriteRenderer sprite = Pacman.transform.GetChild(FindObjectOfType<GameManager>().characterModel).gameObject.GetComponent<SpriteRenderer>();
        sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, 1.0f);

        foreach (Ghost ghost in Ghosts) {
            ghost.gameObject.GetComponent<EnemyController>().frozenMultiplier = 1.0f;
        }

        this.Pacman = null;
    }


}
