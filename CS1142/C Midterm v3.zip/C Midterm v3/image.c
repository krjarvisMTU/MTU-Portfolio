#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int size(const char *arg, int *width, int *height) {
    if (sscanf(arg, "%dx%d", width, height) != 2 || *width > 100 || *height > 100) {
        return 0;
    }
    return 1;
}

int pixel(Image *image, const char *arg) {
    int row, column, value;
    if (sscanf(arg, "%d,%d = %d", &row, &column, &value) != 3 ||
        row < 0 || row >= image->height || column < 0 || column >= image->width || value < 0 || value > 255) {
        return 0;
    }
    image->pixels[row * image->width + column] = (unsigned char)value;
    return 1;
}

int fill_image(Image *image, const char *arg) {
    int value;
    if (sscanf(arg, "%d", &value) != 1 || value < 0 || value > 255) {
        return 0;
    }
    memset(image->pixels, value, image->width * image->height);
    return 1;
}

void output(const Image *image) {
    printf("P2\n");
    printf("%d %d\n", image->width, image->height);
    printf("255\n");
    for (int i = 0; i < image->height; i++) {
        for (int j = 0; j < image->width; j++) {
            printf("%d%c", image->pixels[i * image->width + j], 9);
        }
        printf("\n");
    }
}
