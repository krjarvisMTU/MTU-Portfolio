#include <stdio.h>
#include <stdlib.h>
#include "image.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Error: Missing Image Size Argument\n");
        return 1;
    }
    int width, height;
    if (!size(argv[1], &width, &height)) {
        fprintf(stderr, "Error: Invalid Image Size Argument\n");
        return 1;
    }
    Image *image = malloc(sizeof(Image));
    if (!image) {
        fprintf(stderr, "Error: Memory Allocation Failed\n");
        return 1;
    }
    image->width = width;
    image->height = height;
    image->pixels = calloc(width * height, sizeof(unsigned char));
    if (!image->pixels) {
        fprintf(stderr, "Error: Memory Allocation Failed\n");
        free(image);
        return 1;
    }
    for (int i = 2; i < argc; i++) {
        if (!pixel(image, argv[i]) && !fill_image(image, argv[i])) {
            fprintf(stderr, "Error: Invalid Image Argument: %s\n", argv[i]);
            free(image->pixels);
            free(image);
            return 1;
        }
    }
    output(image);
    free(image->pixels);
    free(image);
    return 0;
}

