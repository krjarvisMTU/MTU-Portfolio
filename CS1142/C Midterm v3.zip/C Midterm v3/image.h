#ifndef IMAGE_H
#define IMAGE_H

typedef struct Image {
    int width;
    int height;
    unsigned char *pixels;
} Image;

int size(const char *arg, int *width, int *height);

int pixel(Image *image, const char *arg);

int fill_image(Image *image, const char *arg);

void output(const Image *image);

#endif
